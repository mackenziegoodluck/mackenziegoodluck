import requests


class Insults:
    '''API to get insults'''

    def __init__(self) -> None:
        '''Creating an object of the api'''
        self.url: str = "https://evilinsult.com/generate_insult.php?lang=en&type=json"

    def get(self) -> str:
        '''Calling the api with the request'''
        r = requests.get(self.url)
        response: dict = r.json()
        return response.get('insult', None)
        