# CS110 Final Exam

## Description of the progam
- The program asks the user 10 multiple choice questions
- If the user gets the question wrong then the program will generate an insult

## KNOWN BUGS
- No known bugs exist
- Better error handling may be needed for if one the api calls goes down

## REFERENCES
- https://evilinsult.com/api/#insults
- https://opentdb.com/api_config.php 

## MISCELLANEOUS COMMENTS
- NOPE
