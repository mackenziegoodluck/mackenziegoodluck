import requests


class Trivia:
    '''API to get Triva questions'''

    def __init__(self, amount: int = 10) -> None:
        '''Creating an object of the api to make certain calls'''

        self.url: str = f"https://opentdb.com/api.php?amount={amount}"

    def get(self) -> str:
        '''Calling the api with the request'''
        r = requests.get(self.url)
        response: dict = r.json()

        return response.get('results', None)
